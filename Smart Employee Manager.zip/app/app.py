
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///employees.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'super-secret-key'

db = SQLAlchemy(app)
jwt = JWTManager(app)

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    department = db.Column(db.String(50))
    role = db.Column(db.String(50))
    date_joined = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    if data.get("username") == "admin" and data.get("password") == "admin":
        token = create_access_token(identity="admin")
        return jsonify(access_token=token), 200
    return jsonify(message="Invalid credentials"), 401

@app.route('/api/employees/', methods=['POST'])
@jwt_required()
def create_employee():
    data = request.json
    if not data.get("name") or not data.get("email"):
        return jsonify(error="Name and Email are required"), 400

    if Employee.query.filter_by(email=data["email"]).first():
        return jsonify(error="Email already exists"), 400

    emp = Employee(
        name=data["name"],
        email=data["email"],
        department=data.get("department"),
        role=data.get("role")
    )
    db.session.add(emp)
    db.session.commit()
    return jsonify(message="Employee created"), 201

@app.route('/api/employees/', methods=['GET'])
@jwt_required()
def list_employees():
    department = request.args.get("department")
    role = request.args.get("role")
    page = int(request.args.get("page", 1))

    query = Employee.query
    if department:
        query = query.filter_by(department=department)
    if role:
        query = query.filter_by(role=role)

    employees = query.paginate(page=page, per_page=10, error_out=False)
    result = []
    for e in employees.items:
        result.append({
            "id": e.id,
            "name": e.name,
            "email": e.email,
            "department": e.department,
            "role": e.role,
            "date_joined": e.date_joined
        })
    return jsonify(result), 200

@app.route('/api/employees/<int:id>/', methods=['GET'])
@jwt_required()
def get_employee(id):
    emp = Employee.query.get(id)
    if not emp:
        return jsonify(error="Employee not found"), 404
    return jsonify({
        "id": emp.id,
        "name": emp.name,
        "email": emp.email,
        "department": emp.department,
        "role": emp.role,
        "date_joined": emp.date_joined
    }), 200

@app.route('/api/employees/<int:id>/', methods=['PUT'])
@jwt_required()
def update_employee(id):
    emp = Employee.query.get(id)
    if not emp:
        return jsonify(error="Employee not found"), 404

    data = request.json
    emp.name = data.get("name", emp.name)
    emp.email = data.get("email", emp.email)
    emp.department = data.get("department", emp.department)
    emp.role = data.get("role", emp.role)
    db.session.commit()
    return jsonify(message="Employee updated"), 200

@app.route('/api/employees/<int:id>/', methods=['DELETE'])
@jwt_required()
def delete_employee(id):
    emp = Employee.query.get(id)
    if not emp:
        return jsonify(error="Employee not found"), 404
    db.session.delete(emp)
    db.session.commit()
    return '', 204

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
