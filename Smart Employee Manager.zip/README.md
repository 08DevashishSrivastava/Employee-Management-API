
# Employee Management REST API (Humanized Version)

## About This Project
This project is a simple backend system that helps a company manage employee information in a digital and secure way. 
Instead of using paper records or Excel files, all employee data is handled through easy-to-use APIs.

With this system, an admin can:
- Add new employees
- View all employees
- Update employee details
- Delete employees when needed

Only authorized users can access these features, making the system safe and reliable. This project follows real-world 
backend practices like authentication, data validation, error handling, pagination, and filtering.

## Why I Built This
I built this project to practice how real companies design backend systems. It helped me understand how data is stored, 
secured, and managed using APIs. It also improved my skills in writing clean, structured, and scalable backend code.

## Tech Used
- Python
- Flask
- SQLite Database
- JWT Authentication

## How to Run
1. Install dependencies:
   pip install -r requirements.txt
2. Start the server:
   python app/app.py

## Login (Get Token)
POST /login  
Use:
{
  "username": "admin",
  "password": "admin"
}

## API Endpoints
- POST /api/employees/   → Create employee  
- GET /api/employees/    → List employees  
- GET /api/employees/{id}/ → Get single employee  
- PUT /api/employees/{id}/ → Update employee  
- DELETE /api/employees/{id}/ → Delete employee  

## Summary (For Interview)
“This project is a secure employee management system built using Python and Flask. It allows adding, viewing, updating, 
and deleting employee records through REST APIs. I also implemented login authentication, validation, filtering, and 
pagination to follow real industry standards.”
